<?php
include_once 'includes/header.php'; 
?>
<div class="col col-lg-12">
  <h1>Page not found!</h1>
</div>