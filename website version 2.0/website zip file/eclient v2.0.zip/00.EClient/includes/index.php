<?php
if (!defined('IN_APP')) {
    //it means it can direct call by url.
    header('Location: ../dashboard.php');
}
?>