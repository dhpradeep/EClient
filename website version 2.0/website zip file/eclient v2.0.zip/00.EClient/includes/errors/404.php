<?php
echo 'Where do you think your going?';