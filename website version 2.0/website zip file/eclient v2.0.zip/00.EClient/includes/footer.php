<div class="col col-lg-12 bg-dark">
    <div class="text-center text-white">Copyright &copy; Eversoft 2018</div>
</div>