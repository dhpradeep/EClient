<?php
include_once('includes/config.php');
#include_once('includes/token.php');
include_once('includes/generate.php');
?>


<!DOCTYPE html>
<html>
<head>
    <title>Signup Page | Eclient</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- css links -->
    <link href="assets/fonts/fonts.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="assets/css/materialize.min.css" media="screen,projection" />
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/mystyle.css" />

    <!-- javascript links -->
    <script src="assets/js/myscript.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/materialize.min.js"></script>
    
    <style>
    .status{
    height: 10px;
    width: 10px;
    background: green;
    border-radius: 50px;
    float:right;
    }
</style>
</head>
<body>